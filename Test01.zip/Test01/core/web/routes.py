
from flask import Blueprint
from .pages import *
from .handlers import *

routes = Blueprint('main', __name__)

@routes.route('/')
def homepage():

    page = Page(title="Home")
    card = Card(title="Card 1")
    section = Section().table(url="api_url")

    card.addSection(section)
    page.addCard(card)

    return page.render()
#enddef