import configparser
from .cardinal import Cardinal

config = configparser.ConfigParser()
config.read("application.cfg")

cardinal = Cardinal(config=config)