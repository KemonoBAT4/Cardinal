
# flask imports
from flask import Flask, request, jsonify, redirect, url_for
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_mail import Mail, Message
from flask_bcrypt import Bcrypt
from flask import current_app


# other imports
import configparser
import json
import os
import importlib

# local imports
from core.models.base import BaseModel, db
from core.web.routes import routes
from core.web.api import api

class Cardinal:

    _config = None
    _app = None
    _app_context = None
    _host = None
    _port = None

    # TODO: complete

    def __init__(self, config=None):

        self._app = Flask(__name__, template_folder="../web/templates")
        self._config = config

        self._app_context = self._app.app_context()
        self._app_context.push()

        self._db = db

        try:
            self._app.config['SQLALCHEMY_DATABASE_URI'] = str(self._config.get("Cardinal Database", "SQLALCHEMY_DATABASE_URI"))
        except Exception as e:
            pass
        #endtry

        # TODO: test if this is correct
        self._host = str(self._config.get("Cardinal", "host"))
        self._port = int(self._config.get("Cardinal", "port"))

        # register routes
        self._app.register_blueprint(routes, url_prefix="/")
        self._app.register_blueprint(api, url_prefix="/api/v")
    #enddef

    def run(self, host=None, port=None):
        """
        DESCRIPTION:
        Runs the application.

        PARAMETERS:
        - host: The host to run the application if different from the default
        - port: The port to run the application if different from the default

        RETURN:
        - no return
        """

        self._host = host if host is not None else self._host
        self._port = port if port is not None else self._port

        self.processRoutes()
        self.processApis()

        self._app.run(debug=True, host=self._host, port=self._port)
    #enddef

    def processRoutes(self):
        """
        DESCRIPTION:
        Dynamically import all route files in the directory provided

        PARAMETERS:
        - filename: The name of the file to import

        RETURN:
        - True if the files were imported successfully, False otherwise
        """

        result = self._processBlueprints("routes")
        return result
    #enddef

    def processApis(self):
        """
        DESCRIPTION:
        Dynamically import all route files in the directory provided

        PARAMETERS:
        - filename: The name of the file to import

        RETURN:
        - True if the files were imported successfully, False otherwise
        """

        result = self._processBlueprints("api")
        return result
    #enddef

    def setup(self):
        """
        DESCRIPTION:
        Sets up the database and creates all tables.

        PARAMETERS:
        - no parameters required

        RETURN:
        - True if the database was set up successfully, False otherwise
        """

        return self._resetDatabase()
    #enddef

    #############
    # UTILITIES #
    #region #####

    def __del__(self):
        self._app_context.pop()
    #enddef

    def _processBlueprints(self, filename="routes.py"):
        """
        DESCRIPTION:
        Dynamically import all route files in the directory provided

        PARAMETERS:
        - filename: The name of the file to import

        RETURN:
        - True if the files were imported successfully, False otherwise
        """

        app_dir = 'app'

        for folder in os.listdir(app_dir):
            folder_path = os.path.join(app_dir, folder)

            if os.path.isdir(folder_path):
                routes_file = os.path.join(folder_path, f"{filename}.py")

                if os.path.isfile(routes_file):
                    module_name = os.path.splitext(os.path.basename(routes_file))[0]
                    module = importlib.import_module(f'{app_dir}.{folder}.{module_name}')
                    bp = getattr(module, module_name)

                    if filename == "routes":
                        self._addBlueprint(bp, f'/{folder}')
                    elif filename == "api":
                        self._addBlueprint(bp, f'/{folder}/api/v{self._config.get("Cardinal", "api")}')
                    #endif
                #endif
            #endif
        #endfor
    #enddef

    def _addBlueprint(self, bluprint, prefix):
        """
        DESCRIPTION:
        Adds a blueprint to the application.

        PARAMETERS:
        - bluprint: The blueprint to add.
        - prefix: The prefix to use for the blueprint.

        RETURN:
        - True if the blueprint was added successfully, False otherwise.
        """

        try:
            self._app.register_blueprint(bluprint, url_prefix=prefix)
            return True
        except Exception as e:
            return False
        #endtry
    #enddef

    def _resetDatabase(self) -> bool:
        """
        DESCRIPTION:
        Resets the database by dropping all tables and creating new ones.

        PARAMETERS:
        - no parameters required

        RETURN:
        - True if the database was reset successfully, False otherwise.
        """

        try:
            if self._db is not None:
                self._db.drop_all()
                self._db.create_all()
                return True
            else:
                raise Exception("Database is not set up. Cannot reset.")
            #endif
        except Exception as e:
            print(f"Error resetting the database: {e}")
            # logger.error(f"Error resetting the database: {e}")
            # logger.debug("See the log file for the complete error.")
        #endtry
        return False
    #enddef

    #endregion ##
#endclass
