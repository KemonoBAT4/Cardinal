
from flask import Blueprint

routes = Blueprint('routes1', __name__)

@routes.route('/test')
def route1Test():
    return 'route 1 test'
#enddef
