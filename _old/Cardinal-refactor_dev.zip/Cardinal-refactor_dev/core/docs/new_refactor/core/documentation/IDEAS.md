### New Cardinal:

app1: -> suo database / suoi modelli

cardinal agisce come un supporto per il database e gestione delle routes / api, ma di una sola applicazione
a questo punto si puo provare a fare di cardinal un'apoplicazione che non gestisce direttamente i database ma bensi un maxi programma che ha come subordinati
i gestori del database, convogliando le informazioni e basta.

cardinal resterà sempre l'applicazione che gestisce i database, ma si farà dare le porte e altre info da il cardinal master