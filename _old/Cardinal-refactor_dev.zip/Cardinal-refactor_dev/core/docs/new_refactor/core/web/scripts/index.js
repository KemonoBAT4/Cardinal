document.addEventListener('DOMContentLoaded', () => {
    console.log('Web application initialized');
});